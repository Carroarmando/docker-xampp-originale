﻿using System;

namespace funzione
{
    class Program
    {
        static int larghezza = Console.BufferWidth; //larghezza della console
        static int altezza = 30; //altezza della console (presa a mano perche BufferHeight torna anche la parte sotto che non vedi)
        static int centroX = larghezza / 2;
        static int centroY = altezza / 2; 

        static void Main(string[] args)
        {
            // Coefficienti dell'equazione (float per farli decimali)
            Console.WriteLine("retta (1) o parabola (2)");
            bool parabola = Convert.ToBoolean(Convert.ToInt16(Console.ReadLine()) - 1);


            if (parabola)
            {
                // Coefficienti dell'equazione (float per farli decimali)
                Console.WriteLine("scrivi la a");
                float a = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("scrivi la b");
                float b = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("scrivi la c");
                float c = Convert.ToSingle(Console.ReadLine());

                Console.Clear(); // Pulisce lo schermo

                // Disegna gli assi cartesiani
                DisegnaAssi(centroX, centroY);

                Parabola(a, b, c);
            }
            else
            {
                // Coefficienti dell'equazione (float per farli decimali)
                Console.WriteLine("scrivi la m");
                float m = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("scrivi la q");
                float q = Convert.ToSingle(Console.ReadLine());

                Console.Clear(); // Pulisce lo schermo

                // Disegna gli assi cartesiani
                DisegnaAssi(centroX, centroY);

                Retta(m, q);
            }

            Console.SetCursorPosition(0, altezza - 1);
            Console.ReadKey();
        }

        static void Retta(float m, float q)
        {
            // Disegna la funzione
            for (int x = -centroX; x < centroX; x++)
            {
                int y = (int)(m * x + q);

                // Controlla se le coordinate x e y sono dentro i limiti dello schermo
                int posX = centroX + x;
                int posY = centroY - y;

                if (posX >= 0 && posX < larghezza && posY >= 0 && posY < altezza)
                {
                    Console.SetCursorPosition(posX, posY);
                    Console.Write("*"); // Disegna il punto
                }
            }
        }

        static void Parabola(float a, float b, float c)
        {
            // Disegna la funzione
            for (int x = -centroX; x < centroX; x++)
            {
                int y = (int)(a * x * x + b * x + c);

                // Controlla se le coordinate x e y sono dentro i limiti dello schermo
                int posX = centroX + x;
                int posY = centroY - y;

                if (posX >= 0 && posX < larghezza && posY >= 0 && posY < altezza)
                {
                    Console.SetCursorPosition(posX, posY);
                    Console.Write("*"); // Disegna il punto
                }
            }
        }

        static void DisegnaAssi(int centroX, int centroY)
        {
            int larghezza = Console.BufferWidth;
            int altezza = 30;

            // Disegna asse orizzontale (asse X)
            for (int x = 0; x < larghezza; x++)
            {
                Console.SetCursorPosition(x, centroY);
                Console.Write("─");
            }

            // Disegna asse verticale (asse Y)
            for (int y = 0; y < altezza; y++)
            {
                Console.SetCursorPosition(centroX, y);
                Console.Write("│");
            }

            // Disegna l'origine (0,0)
            Console.SetCursorPosition(centroX, centroY);
            Console.Write("┼");
        }
    }
}
